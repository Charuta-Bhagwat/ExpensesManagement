﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Drawing;

public partial class Index : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Expense"].ConnectionString);
    ClsExpense ce = new ClsExpense();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1.DataSource = ce.fillData("select * from trnExpenses, mstCategory where trnExpenses.catid = mstCategory.catid order by trnExpenses.catid desc");
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        e.Row.Cells[7].Visible = false;
        if (e.Row.RowType == DataControlRowType.DataRow && GridView1.EditIndex == e.Row.RowIndex)
        {
            DropDownList ddldept = (DropDownList)e.Row.FindControl("ddlCat");
            string sql = "select * from mstCategory";

            using (SqlDataAdapter sda = new SqlDataAdapter(sql, con))
            {
                using (DataTable dt = new DataTable())
                {
                    sda.Fill(dt);
                    ddldept.DataSource = dt;
                    ddldept.DataTextField = "category";
                    ddldept.DataValueField = "catid";
                    ddldept.DataBind();
                    string selectedCity = DataBinder.Eval(e.Row.DataItem, "category").ToString();
                    ddldept.Items.FindByText(selectedCity).Selected = true;
                }
            }

        }
        if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex != GridView1.EditIndex)
        {
            (e.Row.Cells[6].Controls[2] as LinkButton).Attributes["onclick"] = "return confirm('Do you want to delete this row?');";
        }
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int expid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
        ce.Execute("delete from trnExpenses where expid='" + expid + "'");
        GridView1.DataSource = ce.fillData("select * from trnExpenses, mstCategory where trnExpenses.catid = mstCategory.catid order by trnExpenses.catid desc");
        GridView1.DataBind();
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = (GridViewRow)GridView1.Rows[e.RowIndex];
        int userid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString());
        string expid = (row.Cells[7].Controls[0] as TextBox).Text;
        string expense = (row.Cells[1].Controls[0] as TextBox).Text;
        string catid = (row.FindControl("ddlCat") as DropDownList).SelectedValue.ToString();
        string amount = (row.Cells[3].Controls[0] as TextBox).Text;
        string remark = (row.Cells[4].Controls[0] as TextBox).Text;
        if (expense.Trim() != "" && amount.Trim() != "")
        {
            ce.Execute("update trnExpenses set expense='" + expense + "', catid='" + catid + "', amount='" + amount + "', remark='" + remark + "' where expid='" + expid + "'");
        }
        GridView1.EditIndex = -1;
        GridView1.DataSource = ce.fillData("select * from trnExpenses, mstCategory where trnExpenses.catid = mstCategory.catid order by trnExpenses.catid desc");
        GridView1.DataBind();
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource = ce.fillData("select * from trnExpenses, mstCategory where trnExpenses.catid = mstCategory.catid order by trnExpenses.catid desc");
        GridView1.DataBind();
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        GridView1.DataSource = ce.fillData("select * from trnExpenses, mstCategory where trnExpenses.catid = mstCategory.catid order by trnExpenses.catid desc");
        GridView1.DataBind();
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }


    protected void DownloadFile(object sender, EventArgs e)
    {
        int id = int.Parse((sender as LinkButton).CommandArgument);
        byte[] bytes;
        string fileName, contentType;
        using (SqlCommand cmd = new SqlCommand())
        {
            cmd.CommandText = "select filename, filedata, filetype from trnExpenses where expid=@Id";
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.Connection = con;
            con.Open();
            using (SqlDataReader sdr = cmd.ExecuteReader())
            {
                sdr.Read();
                bytes = (byte[])sdr["filedata"];
                contentType = sdr["filetype"].ToString();
                fileName = sdr["filename"].ToString();
            }
            con.Close();
        }

        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = contentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
        Response.BinaryWrite(bytes);
        Response.Flush();
        Response.End();
    }


    protected void ExportToExcel(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.ClearContent();
        Response.ClearHeaders();
        Response.Charset = "";
        string FileName = "Expenses" + DateTime.Now + ".xls";
        StringWriter strwritter = new StringWriter();
        HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/vnd.ms-excel";
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
        GridView1.GridLines = GridLines.Both;
        GridView1.HeaderStyle.Font.Bold = true;
        GridView1.Columns[5].Visible = false; GridView1.Columns[6].Visible = false;
        GridView1.RenderControl(htmltextwrtter);
        Response.Write(strwritter.ToString());
        GridView1.Columns[5].Visible = true; GridView1.Columns[6].Visible = true;
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
}