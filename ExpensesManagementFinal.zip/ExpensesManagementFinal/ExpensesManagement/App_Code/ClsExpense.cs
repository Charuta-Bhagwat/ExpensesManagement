﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for ClsExpense
/// </summary>
public class ClsExpense
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Expense"].ConnectionString);

	public ClsExpense()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable fillData(string qry)
    {
        if (con.State == ConnectionState.Open)
            con.Close();
        con.Open();
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand(qry, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        return dt;
    }

    public void fill(string qry, string val, string txt, DropDownList ddl, string select)
    {
        if (con.State == ConnectionState.Open)
            con.Close();
        con.Open();
        ddl.Items.Clear();
        SqlCommand cmd = new SqlCommand(qry, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        ddl.DataValueField = val;
        ddl.DataTextField = txt;
        ddl.DataSource = dt;
        ddl.DataBind();
        con.Close();
        ddl.Items.Insert(0, new ListItem(select, "0"));
    }

    public void Execute(String sql)
    {
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandTimeout = 120;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
        
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
       
    }

    public string getID(string tablename, string filedname, string name, string values)
    {
        string a = "0";

        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand("select " + filedname + " from " + tablename + " where " + name + "=N'" + values + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            a = dr.GetValue(0).ToString();
        }
       
        if (a == "")
        {
            a = "0";
        }
        
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }

        return a;

    }
}